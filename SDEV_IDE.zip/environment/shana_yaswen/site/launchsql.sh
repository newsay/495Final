mysqlpath="..\..\mysql\bin\mysql"
user="aritchie"
password="pFfcm4hUC8kNabxR"
host="csc495.cmmdzy4o0hbl.us-east-2.rds.amazonaws.com"
mysql -u $user --password=$password -h $host