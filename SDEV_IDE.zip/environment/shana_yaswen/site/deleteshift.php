<?php
/**
 * @author  Andrew Ritchie, Robert Martinez, John Leavitt
 */
include_once $_SERVER['DOCUMENT_ROOT'] . '/misc/init.php';
/*
 * If the page you are authoring requires authorization, uncomment one of the following
 * lines and the second to last line of this file.
 */

//Uncomment the following line for a Manager-only page, such as New Shift
if (authorize($auth_service, $organization_service, User::USER_TYPE_MANAGER)) {

    $shiftid = $_GET["id"];
    $shift = $shift_service->get_shift($shiftid);
    $timestart = date("H:i:s",$shift->get_start_datetime());
    $datestart = date("Y-m-d",$shift->get_start_datetime());
    $timeend = date("H:i:s",$shift->get_end_datetime());
    $dateend = date("Y-m-d",$shift->get_end_datetime());
    if ($auth_service->get_user_organization() != $shift->get_organization_id()) {
        redirect("managerdashboard.php");
    }
    else {
    page_start($auth_service, "Scheduling OnDemand - Delete Shift");
   
    ?>
    <div class="container">
        <div class="row">
            <div class="col-md-6 center-block" style="float:none">
                <h1 class="text-center">Delete Shift</h1>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 center-block" style="float:none">
                <h1 class="text-center">Are you sure you want to delete this shift?</h1>
                <div class="btn-group">
          <div onclick="managerdashboard.php?id=<?php echo $shiftid ?>">
          
          <a class="btn btn-default" href="managerdashboard.php?id=<?php echo $shiftid ?>">Yes</a>
          </div>
        </div>
        <div class="btn-group">
          <div onclick="shiftdetails.php?id=<?php echo $shiftid ?>">
          <a class="btn btn-default" href="shiftdetails.php?id=<?php echo $shiftid ?>">No</a>
          </div>
        </div>
            </div>
        </div>
        
    </div>
    
    
    <?php
 
    page_end();
    }
}
?>