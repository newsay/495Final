<?php
include_once $_SERVER['DOCUMENT_ROOT'] . '/misc/init.php';
/*
 * If the page you are authoring requires authorization, uncomment one of the following
 * lines and the second to last line of this file.
 */
//Uncomment the following line for an Employee-only page, such as the Employee Dashboard
//if (authorize($auth_service, $organization_service, User::USER_TYPE_EMPLOYEE)) {

//Uncomment the following line for a Manager-only page, such as New Shift
//if (authorize($auth_service, $organization_service, User::USER_TYPE_MANAGER)) {

//Uncomment the following line for an Administrator-only page, such as New Organization
//if (authorize($auth_service, $organization_service, User::USER_TYPE_ADMINISTRATOR)) {

//Uncomment the following line for a page that requires being logged in, but all user-types can access, such as View Profile
//if (authorize($auth_service, $organization_service)) {
    page_start($auth_service, "Scheduling OnDemand - My Page");
    ?>
    <div class="container">
        <div class="row">
            <div class="col-md-6 center-block" style="float:none">
                <h1 class="text-center">Example Content</h1>
            </div>
        </div>
        <?php
        //The following is an example of how to create a simple form.
        $fields = array(
            array('id' => 'inputFieldOne', 'name' => 'fieldOne', 'display_text' => "Field One", 'placeholder_text' => "Field One Placeholder", 'width' => 12, 'required' => true),
            array('id' => 'inputFieldTwo', 'type' => 'password', 'name' => 'fieldTwo', 'display_text' => "Field Two"),
            array('id' => 'inputFieldThree', 'type' => 'date', 'name' => 'fieldThree', 'display_text' => "Field Three"),
            //Add a hidden field
            //This can be useful for keeping track of multi-step forms, such as Reset Password, where multiple levels of input are useful.
            //i.e. "Input email address" and then "Input security question answers"
            //In that case, we'd have a hidden field "stage" that gets incremented for each stage of the form
            array('id' => 'inputHiddenField', 'type' => 'hidden', 'name' => 'hiddenField', 'default' => "Field to Pass to POST")
            );
        $errors = array();
        //Check to see if the form has posted
        if ($_POST) {
            //Check if required fields have been populated
            $errors = required_fields_errors($fields);
            //Do additional validation
            if (strlen($_POST["fieldOne"]) != 5) {
                add_error($errors, "fieldOne", "Field One must be 5 characters");
            }
        }
        //Check if the form is ready for processing
        if ($_POST && sizeof($errors) == 0) {
            //Do something with the post result
            //This is where you would call things like $user_service->create_user, etc.
            echo("You input:");
            echo("<br>Field One: " . htmlentities($_POST["fieldOne"]));
            echo("<br>Field Two: " . htmlentities($_POST["fieldTwo"]));
            echo("<br>Field Three: " . htmlentities($_POST["fieldThree"]));
            echo("<br>Hidden : " . htmlentities($_POST["hiddenField"]));
            ?>
            <br>You can also put <strong>HTML blocks</strong> here
            <?php
            //It can also be common to redirect to the dashboard after submitting.
            //In that case, this logic would insteadgo before the "page_start" method near the beginning of this page
            //You would then call the following:
            //redirect('index.php');
        }
        else {
            //If the form hasn't yet been submitted, display it.
            ?>
            <form method="POST" action="boilerplate.php">
                <?php
                build_form($fields, $errors);
                ?>
                <div class="form-group row">
                    <div align="center" class="col-sm-12">
                       <button type="submit" class="btn btn-default">Submit</button>
                    </div>
                </div>
            </form>
            <?php
        }
        ?>
    </div>
    
    
    <?php
    page_end();
//}
?>