/* 

----- USERS VALUES ----- 
MANAGER = 1
USER = 0
ADMIN = 2

----- SHIFT VALUES -----
UNASSIGNED = 0
ASSIGNED = 1

----- REQUEST VALUES -----
*STATUS*
PENDING = 0
APPROVED = 1
DENIED = 2

*TYPE*
ASSIGNMENT = 0
CANCELATION = 1


/* ------------- Insert Organizations ----------------------- */

INSERT INTO Organizations (OrganizationID,OrganizationName,IsEnabled)
VALUES ('','UMUC', '1');

INSERT INTO Organizations (OrganizationID,OrganizationName,IsEnabled)
VALUES ('','Scheduling OnDemand', '1');

/* ------------- Insert Users ----------------------- */

INSERT INTO Users (UserID,OrganizationID,UserType,Password,Email,FirstName,LastName,HomePhone,MobilePhone,Address1,Address2,City,State,ZipCode,SecurityQuestion1,SecurityQuestion1Answer,SecurityQuestion2,SecurityQuestion2Answer,SecurityQuestion3,SecurityQuestion3Answer)
VALUES ('','1','1','$2y$10$qXvpgEoI7M6zxRgpecOaGuAL2GMWBsuV6XLz5hX.aSBCrQoqPzqsW','manager1@gmail.com','Billy','Johnson','210-234-7685','210-222-0987','123 Main Street','Apt 1','Washington','District of Columbia','78254-0000','1. What is your favorite color? (blue)','$2y$10$0EhZdo10lE/WF67XbTzQoOnWgdvy8OfXTpizZ3JTJQv2DX6TLiOoC','2. Where did you meet your spouse? (New York)','$2y$10$aZFjW1NU4qVqYxc0gBTYdurrDeGRro9iGYMqJw3f8Vzl09JKnwigW','3. What is the make of your car? (Audi)','$2y$10$fpsAy2MG8pwScQgN83PIhu8BYPGXOs0euOrzXK3B0ul58farf1UL6');

INSERT INTO Users (UserID,OrganizationID,UserType,Password,Email,FirstName,LastName,HomePhone,MobilePhone,Address1,Address2,City,State,ZipCode,SecurityQuestion1,SecurityQuestion1Answer,SecurityQuestion2,SecurityQuestion2Answer,SecurityQuestion3,SecurityQuestion3Answer)
VALUES ('','1','0','$2y$10$urHB.sT4Su.gXsCbv2/nN.yIoNE/tnLhTxHMZyK4bwKBXSmqnEfdC','user1@gmail.com','Tom','Smith','345-567-3421','234-444-5566','345 Avue C','','Washington','District of Columbia','78245-0457','1. What is your child hood nickname? (tom cat)','$2y$10$fpsAy2MG8pwScQgN83PIhu8BYPGXOs0euOrzXK3B0ul58farf1UL6','2. What is your favorite vacation spot? (cabo)','$2y$10$xbr5DjODaVXn2.38/QOGNu0MIA4su./Rz7MjWHz/XeLefA7XMHCKO','3. Name of your first employer? (Cyber Smart)','$2y$10$qhQTNCOL5k7JVvWMtSnvauJTiF0lybQQ57iKVOlml/EBKuTDHz296');

INSERT INTO Users (UserID,OrganizationID,UserType,Password,Email,FirstName,LastName,HomePhone,MobilePhone,Address1,Address2,City,State,ZipCode,SecurityQuestion1,SecurityQuestion1Answer,SecurityQuestion2,SecurityQuestion2Answer,SecurityQuestion3,SecurityQuestion3Answer)
VALUES ('','2','1','$2y$10$.s5Mub/PHUypn6CLrErLjukXVHvTcVxZ1DF6E3JoKC28TM0gzea/6','manager2@gmail.com','Jeff','Jackson','123-234-4433','123-444-5555','1234 West Point','','Washington',' District of Columbia','78254-9999','1. What is your favorite colore? (red)','$2y$10$hHriD6Evpj7VBYBv7s8CrO7I0/NmVNNYVnNS6/HoEIRIHgXE3Kwl6','2. Middle name of your oldest sibling? (Julie)','$2y$10$jfiFxBPQdYUQRuBjanJyRe3gKqzhRKafoc9eDXXaJ/wn8XNwXj4.i','3. What was your high school mascot? (ram)','$2y$10$Qt.idsjEzxsCE5QpJaYTcuWMHHWuZIhGlkySyD5VhW1iZ1/z6WCVq');

INSERT INTO Users (UserID,OrganizationID,UserType,Password,Email,FirstName,LastName,HomePhone,MobilePhone,Address1,Address2,City,State,ZipCode,SecurityQuestion1,SecurityQuestion1Answer,SecurityQuestion2,SecurityQuestion2Answer,SecurityQuestion3,SecurityQuestion3Answer)
VALUES ('','2','0','$2y$10$zE6QUMg4xEruEpY6tGLvqee.ghdIG.nEJ0pGttJEQ6HFtXYvGRzse','user2@gmail.com','Jackie','Road','222-333-4455','444-555-6655','3456 West Over Hills','','Washington','District of Columbia','78254-2345','1. What is your favorite color? (green)','$2y$10$oFDqhJuUr5yFo/Vf23UlweOC.q.SHvDmnIsnJOxJ17V0HnO2qU..m','2. What is the name of your first pet? (turbo)','$2y$10$wbVuQXx/YnoLWScYVvoKteSEchKXz6LnSfVGdQPlAHx1fOcaCtndu','3. Name of the last concert you attended? (George Strait)','$2y$10$HXe/NLQtGD01bv6As.4rjeht94O2fMqtPc7kgumseOQ1mOSmaeIRC');

INSERT INTO Users (UserID,OrganizationID,UserType,Password,Email,FirstName,LastName,HomePhone,MobilePhone,Address1,Address2,City,State,ZipCode,SecurityQuestion1,SecurityQuestion1Answer,SecurityQuestion2,SecurityQuestion2Answer,SecurityQuestion3,SecurityQuestion3Answer)
VALUES ('','1','2','$2y$10$8k1NBFcRoNWLCtIzjjsk4.OwBpsSnDOOdjTc00p7/9mAd2K0Y0CbW','admin1@gmail.com','Rose','Blue','345-567-9999','456-543-5544','2222 Back Road','','Washington','District of Columbia','78254-1928','1. What is your favorite song? (Patience)','$2y$10$YeqmK673v48.dau13e7IpO6cKN9hJvni7FCy9fqKk6K3gLjL9JPau','2. Where was your last vacation to? (Cabo)','$2y$10$QaSp9If4pGOhfqa1D0DLAOtpHDFxPQCS2lxUaSg0qJw1n2acZvDmK','3. What year did you graduate? (2007)','$2y$10$ZCoWejViPTwOIbw3/jS6Iulo69oSmcrit2.uOXGz9S0Sh8.fRTXq2');


/* ------------- Insert Shifts ----------------------- */

INSERT INTO Shifts (ShiftID,Status,OrganizationID,ZipCode,RequiredPosition,PayDifferential,StartDate,StartTime,EndDate,EndTime,SpecialRequirements)
VALUES ('','0','1','78254-0000','RN','89.50','2019-07-01','13:00','2019-07-01','22:00','Gender: Male, Language: Spanish Speaking, Experience: Vent');

INSERT INTO Shifts (ShiftID,Status,OrganizationID,ZipCode,RequiredPosition,PayDifferential,StartDate,StartTime,EndDate,EndTime,SpecialRequirements)
VALUES ('','0','1','78254-1122','LVN','75.99','2019-06-30','09:00','2019-06-30','23:00','Language: Spanish Speaking, Experience: Children under 2 yrs old');

INSERT INTO Shifts (ShiftID,Status,OrganizationID,ZipCode,RequiredPosition,PayDifferential,StartDate,StartTime,EndDate,EndTime,SpecialRequirements)
VALUES ('','0','1','78254-7744','RN/LVN','80.00','2019-07-02','17:00','2019-07-02','22:00','');

INSERT INTO Shifts (ShiftID,Status,OrganizationID,ZipCode,RequiredPosition,PayDifferential,StartDate,StartTime,EndDate,EndTime,SpecialRequirements)
VALUES ('','0','1','78254-1234','RN','94.80','2019-07-03','18:00','2019-07-04','03:00','Gender: Female');

INSERT INTO Shifts (ShiftID,Status,OrganizationID,ZipCode,RequiredPosition,PayDifferential,StartDate,StartTime,EndDate,EndTime,SpecialRequirements)
VALUES ('','0','1','78254-9999','LVN','78.00','2019-07-01','07:00','2019-07-01','17:00','Experience: Vent');

INSERT INTO Shifts (ShiftID,Status,OrganizationID,ZipCode,RequiredPosition,PayDifferential,StartDate,StartTime,EndDate,EndTime,SpecialRequirements)
VALUES ('','0','1','78254-1289','RN','69.00','2019-07-05','08:00','2019-07-05','13:00','');

INSERT INTO Shifts (ShiftID,Status,OrganizationID,ZipCode,RequiredPosition,PayDifferential,StartDate,StartTime,EndDate,EndTime,SpecialRequirements)
VALUES ('','0','1','78254-9876','LVN','59:87','2019-07-05','12:00','2019-07-05','16:00','');

INSERT INTO Shifts (ShiftID,Status,OrganizationID,ZipCode,RequiredPosition,PayDifferential,StartDate,StartTime,EndDate,EndTime,SpecialRequirements)
VALUES ('','0','1','78254-7777','RN/LVN','71:25','2019-07-08','16:00','2019-07-08','23:00','');

INSERT INTO Shifts (ShiftID,Status,OrganizationID,ZipCode,RequiredPosition,PayDifferential,StartDate,StartTime,EndDate,EndTime,SpecialRequirements)
VALUES ('','0','1','78254-1945','LVN','77:50','2019-07-11','23:00','2019-07-12','09:00','');

INSERT INTO Shifts (ShiftID,Status,OrganizationID,ZipCode,RequiredPosition,PayDifferential,StartDate,StartTime,EndDate,EndTime,SpecialRequirements)
VALUES ('','0','1','78254-5511','RN','80:25','2019-07-12','19:00','2019-07-13','03:00','');

/* ------------- Insert Assigned Shifts ----------------------- */

INSERT INTO Requests (RequestID,ShiftID,UserID,Status,Type)
VALUES ('','2','2','0','0');

INSERT INTO Requests (RequestID,ShiftID,UserID,Status,Type)
VALUES ('','4','4','0','0');

INSERT INTO Requests (RequestID,ShiftID,UserID,Status,Type)
VALUES ('','6','2','1','0');

INSERT INTO Requests (RequestID,ShiftID,UserID,Status,Type)
VALUES ('','8','4','2','0');

INSERT INTO Requests (RequestID,ShiftID,UserID,Status,Type)
VALUES ('','10','2','2','1');

INSERT INTO Requests (RequestID,ShiftID,UserID,Status,Type)
VALUES ('','1','4','1','1');